
import java.util.Scanner;

//3 Character Based Write a Java Program to check whether a character is alphabet or not.
public class co23
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        char a=sc.next().charAt(0);
        if(a>='a'&&a<='z'||a>='A'&&a<='Z')
        {
            System.out.println("alphabet");
        }
        else{
            System.out.println("not");
        }
    }
}